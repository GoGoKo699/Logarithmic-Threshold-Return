# Development and preservation record

**4 October 2026.** This file records limitations of the actual work, rather than treating all exploratory runs as successful evidence.

The first exploratory residual-depth sweep was interrupted by its enclosing execution limit before its final case and before an aggregate JSON was saved. Printed exploratory values were used only to select controls; that sweep is not counted as a completed suite. A second exploratory high-grid scan was similarly interrupted after printing some rows, and is not a validation result.

The first full suite, using a fixed 600-node-per-half-band continuum grid, passed five groups and failed the independent grid/tolerance check in the sixth. Its log and the then-current scientific source are retained in `development/`. This was a genuine quadrature-resolution failure, not norm loss and not a repaired physics formula. A grid scan showed convergence beyond the underresolved rows. The failed-reference attempt produced no `results.json` and has not been counted as a pass.

The corrected calculation uses `max(800,ceil(5*T))` quadrature nodes per half band for the main infinite-lattice sweeps. A separate 2400-node, tighter-tolerance check at T=300 and a 6500-node check at T=1000 verify the affected regime. The criterion was not loosened to make the old grid pass. The actual completed run is in `development/GRID_REPAIRED_RUN.log`; its output is the first canonical new reference.

The former auxiliary scans are not all computed at the final resolution and are not authoritative values. No claim of a universal monotonic dependence on duration or side length comes from them. Only `results.json` and the independent retained validation output supply the reported finite numerical values.

The earlier threshold scripts and results were not changed. The supplied scout07 archive is preserved byte-for-byte and contains the earlier two threshold archives. Their CRCs and hashes are checked; their scientific suites are not rerun during this pass. No established repository is used for these files.

The clean reproduction runs the new code and companion model in an otherwise empty temporary directory with one numerical thread. Its output is written to a new path and compared field by field. Exact byte agreement, a numerically accepted difference, and passing assertions are recorded separately. Those distinctions do not amount to independent scientific review.
