# Primary-source comparison and access record

**4 October 2026.** Sources below support established ingredients and scoped comparisons. New spectral/ODE calculations and the matched-asymptotic coefficient are our work. Full-text availability does not mean every proof was independently checked. No PDF is redistributed, no source plot is used to extract numerical results, and no exhaustive priority audit is claimed.

## S1. Energy-space treatment and the 38-percent comparator

D. Sokolovski and M. Pons, *Adiabaticity in a time-dependent trap: The passage near a continuum threshold*, Physical Review A 92, 042121 (2015). Full author text: https://arxiv.org/pdf/1506.04019 ; DOI https://doi.org/10.1103/PhysRevA.92.042121 .

Inspected Sections II–V, the Fourier/Sturmian equations (7)–(15), the single-Sturmian equation (21), and the bound-amplitude/reflection interpretation. The paper explicitly reduces a quadratic temporal potential to energy-space differential equations and an absorbing-potential reflection problem. Its text says the framework also offers advantages in higher-dimensional calculations. We therefore claim an exact rank-one lattice specialization, not invention of the method. Its one-dimensional zero-range and slow finite-range results give the known 38-percent comparator. No figure value is reused.

## S2. Scope of variable-power touching universality

D. Sokolovski and M. Pons, *Adiabaticity in a time-dependent trap: A universal limit for the loss by touching the continuum*, Physical Review A 94, 013410 (2016). https://arxiv.org/pdf/1603.08718 ; https://doi.org/10.1103/PhysRevA.94.013410 .

Inspected introduction, one-dimensional model and scaling, discussion of arbitrary approach powers, and stated conclusion. Its introduction credits Devadriani's older three-dimensional zero-range 38-percent result, so that number should not be represented as exclusively one-dimensional in every context. The inspected universality argument is tied to its threshold reduction, not a universal dimension-independent constant. Our bare lattice depth is not the same control parameter as a renormalized continuum contact strength. Neither a changed dimension nor a different plot establishes novelty by itself.

## S3. A rigorous diving-into-continuum theorem, now inspected beyond the abstract

H. D. Cornean, A. Jensen, H. K. Knorr, G. Nenciu, *On the adiabatic theorem when eigenvalues dive into the continuum*, Reviews in Mathematical Physics 30, 1850011 (2018). https://arxiv.org/pdf/1612.02354 .

Inspected model, Assumptions 1.1–1.2, Theorem 1.3, Remarks 1.4–1.5 and concluding extensions. The form factor vanishes at zero momentum; their critical state is normalizable, with a norm-limit projection. The ionization theorem requires a true-resonance interval. The remarks discuss dimensional extensions tied to resolvent smoothness, and distinguish resonance-threshold difficulties. Our disappearing state at an instant is outside these particular hypotheses. We have not ruled out every extension of their method or every other adiabatic theorem. This reading closes the precise abstract-only gap from scout05, not all priority questions.

## S4. Time-dependent two-dimensional contacts already have a rigorous formulation

R. Carlone, M. Correggi, R. Figari, *Two-dimensional time-dependent point interactions* (2017), author text https://arxiv.org/pdf/1601.02390 ; publisher https://doi.org/10.4171/175-1/10 .

Inspected Section 1, charge equations (1.18)–(1.20), Theorem 1.1 and the logarithmic Volterra kernel discussion. The result constructs unitary nonautonomous evolution from a low-dimensional charge equation. It does not state our single slow round-trip return asymptotic. This is a continuum self-adjoint-extension model, not literally the finite-strength on-site lattice potential. General solvability of the evolution does not by itself supply the coefficient of an adiabatic return law.

## S5. Two-dimensional periodic ionization with a different logarithmic law

W. Borrelli, R. Carlone, L. Tentarelli, *Complete ionization for a non-autonomous point interaction model in d=2*, Communications in Mathematical Physics 395, 963–1005 (2022). https://arxiv.org/pdf/2108.06564 ; https://doi.org/10.1007/s00220-022-04447-1 .

Inspected introduction, the monochromatic assumption (14), Theorem 1.3 and Remarks 1.2–1.5. The forcing is alpha_0 sin(omega t+eta)+c at a fixed frequency, with a no-resonance condition. Long-time survival is O((log t/t)^2), with possible cancellations of leading coefficients. The zero contact parameter is not the free Laplacian; Remark 1.2 explicitly warns of this. The single-cycle slow limit here is not that repeated-period long-observation limit. The inspected theorem does not imply our 1/log^2(T) result by replacing a symbol. We have not checked every estimate of this 38-page author manuscript independently.

## Inherited static and component references

The exact square-lattice Green function and its elliptic form are established; scout05 credits A. J. Guttmann, *Lattice Green functions in all dimensions*, https://arxiv.org/abs/1004.1435 . The essential weak-binding phenomenon is credited there to Simon and later two-dimensional analyses. Their static results must not be repackaged as our dynamical discovery. The unchanged preceding source register, including its component-level experimental precedents and limitations, is preserved in evidence/fresh_scout_05_threshold_return.zip.

The present pass does not add a complete apparatus audit. Ideal addressing, depth control, source preparation, thermodynamic order of limits and recapture detection have not been jointly validated by this list.

## Search limits

The searches covered logarithmic and two-dimensional adiabatic threshold touching, energy-space trapping, and time-dependent point interactions/ionization. Several broad searches returned unrelated material and provide no negative novelty evidence. The five papers above were compared at the specified primary-text locations. Absence of our exact formula in those locations does not establish exhaustive originality, let alone editorial significance. No researcher was contacted and no protected repository was inspected.
