# Primary sources and scope of this audit

**4 October 2026.** Source statements below are distinct from the new calculations in AUDIT.md and checks.py. No third-party PDF is included in the delivered archive. This is a targeted comparison, not an exhaustive citation-network or priority review.

## S1. Sokolovski and Pons, 2015

*Adiabaticity in a time-dependent trap: The passage near a continuum threshold*, Physical Review A 92, 042121 (2015).

- Author full text: https://arxiv.org/pdf/1506.04019
- Published identifier: https://doi.org/10.1103/PhysRevA.92.042121

Relevant sections re-inspected: II–III, Eqs. (7)–(15), for the Fourier/Sturmian reduction; IV, Eqs. (21)–(26), for absorbing energy scattering and stationary-phase normalization; V, Eqs. (27)–(31), for the Hankel solution and 4cos^2(2pi/5) coefficient. These establish the method and a known nonzero return plateau. The precise inverse-square-logarithmic lattice law is not stated in these inspected equations.

The general spectral-power Bessel identity used in our audit is obtained by the explicit small-argument matching in AUDIT.md; it is not represented as a newly discovered general mathematical principle or as a result quoted verbatim from S1. No numerical value was read from a figure in this pass.

## S2. Sokolovski and Pons, 2016

*Adiabaticity in a time-dependent trap: A universal limit for the loss by touching the continuum*, Physical Review A 94, 013410 (2016).

- Author full text: https://arxiv.org/pdf/1603.08718
- Published identifier: https://doi.org/10.1103/PhysRevA.94.013410

Section X explicitly describes its one-dimensional finite-power approach E_n(t) approximately -(v|t|)^(2nu), with a limiting retention determined by nu. It notes that evaluation generally requires fractional-order equations and treats large nu numerically. The same section says threshold states dominate while far-continuum structure is unimportant. That physical organizing idea is inherited, not introduced by our passive-load estimate.

Our binding approaches zero essentially, rather than with one fixed power of time. Sending their nu to infinity with a T-dependent guess is not their stated theorem or a uniform derivation of our law. Conversely, the absence of the same printed formula is not a proof of originality. The new audit's sigma is an energy-equation exponent, not their time-schedule nu.

## S3. Avron and Elgart, 1999

*Adiabatic Theorem without a Gap Condition*, Communications in Mathematical Physics 203, 445–463 (1999).

- Author full text, v4: https://arxiv.org/pdf/math-ph/9805022
- Published identifier: https://doi.org/10.1007/s002200050620

Sections 2 and 4 were inspected for Theorem 1 and the commutator method, Eqs. (7)–(9). Theorem 1 requires a smooth finite-rank spectral projection for a smooth bounded Hamiltonian; later sections weaken smoothness under additional conditions. The new bound-vector overlap calculation demonstrates that our projection has no norm-continuous extension at touching, so this prerequisite already fails. We do not claim that gap closing alone invalidates all adiabatic theorems.

The gapped-tail comparison uses the established commutator integration-by-parts mechanism. A complete outside review of the half-line estimates is still absent. The associated radiation-field example is not imported as another model or used to reopen a protected research project.

## Comparisons carried from scout06, not counted as fresh reviews

The supplied SOURCES.md and ASYMPTOTIC.md preserve the focused comparisons with Cornean–Jensen–Knorr–Nenciu (2018), arXiv:1612.02354, and Borrelli–Carlone–Tentarelli (2022), arXiv:2108.06564. Their respectively overcritical interval and fixed-frequency periodic-forcing limits are not automatically the present single slow touching cycle. The current pass re-opened the Cornean primary text for orientation but does not claim a new full-paper audit of it, nor a new review of the two-dimensional point-interaction charge equation.

Static logarithmic binding and square-lattice Green functions remain inherited from scout05's source register. The outgoing spectral-boundary estimate does not establish every two-dimensional microscopic potential as part of one universality theorem.

## Search boundary

Targeted public searches were performed for threshold touching, two-dimensional slow recapture, logarithmic return, and relevant author/title combinations, including potentially recent work. Many broad queries returned irrelevant material; those results were not used. The inspected primary comparisons did not provide an exact subsumption of the current lattice law. This is not evidence that no such result exists, and it is not a completed novelty certificate.

No assumption-quota completion is claimed. The preparation, depth control, large coherent lattice, residual confinement and recapture apparatus still lack a completed joint provenance audit at the user's five-to-ten-paper standard. Component feasibility is not a demonstrated whole experiment.
