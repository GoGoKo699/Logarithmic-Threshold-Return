# Source and attribution map

**4 October 2026.** This pass asks how residual attraction and finite size round the already recorded local-trap result. It is research expansion, not extraction of new results from these papers. The coefficient, finite-size bound and numerical values labeled as this scout's calculations are author-side work. No third-party PDF is redistributed.

## Sources inspected in this pass

**S1 — D. Sokolovski and M. Pons, Adiabaticity in a time dependent trap: a passage near continuum threshold (2015).** [Primary author PDF](https://arxiv.org/pdf/1506.04019).

The retrieved record is the 11-page arXiv version. Section II, Eq. (6), explicitly includes a quadratic round trip turning below, touching, or crossing the threshold. Sections III–IV, especially Eqs. (21)–(26), give the auxiliary energy-scattering description and identification of the reflected/incoming amplitude ratio. The end of Section IV explains gapped adiabatic return through a forbidden energy-coordinate region. These are direct foundations of the present analysis, not new principles established by adding a residual depth. Their displayed zero-range model and threshold reduction are not the square-lattice logarithmic coefficient, and no inspected theorem there was found to state the joint residual/volume law derived here. This is a scoped comparison, not a proof of exhaustive novelty. No values were extracted from figures.

**S2 — S. Jansen, M.-B. Ruskai and R. Seiler, Bounds for the adiabatic approximation with applications (2007).** [Primary author PDF](https://arxiv.org/pdf/quant-ph/0603175).

Sections II–III state the differentiability, spectral-isolation and projection assumptions, and Theorem 1 gives fixed-family adiabatic bounds. The explicit gap dependence discussed in Section V and Theorems 3–4 matters when the gap changes between members of a scaling family. This supports the distinction between a fixed nonzero minimum/fixed finite lattice and the joint sequence considered here. We do not attribute our residual coefficient or finite-size propagation estimate to that paper. Nor does the usual fixed-family theorem imply a uniform bound when an exponentially small gap depends on the run time. No table or figure values are imported.

**S3 — D. Sokolovski and M. Pons, Adiabaticity in a time-dependent trap: a universal limit for the loss by touching the continuum (2016), arXiv:1603.08718.** [Primary author PDF](https://arxiv.org/pdf/1603.08718).

This is the previously used finite-power touching comparison. Its opening discussion credits the earlier three-dimensional zero-range 38-percent result and treats broader one-dimensional control powers. The present round does not repeat its full derivation or label the 38-percent constant exclusively one-dimensional. A temporal-ramp exponent is not the logarithmic residual parameter $b$ of ROUNDING.md. The directly relevant departure from exact touching already appears in S1. Equation (5) of S3 also explicitly gives the midpoint squared-wavefunction return identity used in the present real, time-symmetric calculations. This identity is inherited, not new; S3 is not an extra independent validation of the residual coefficient.

## Inherited source checks, not newly repeated

The predecessor archive contains the exact lattice Green function and weak-binding attribution, the gapless-projection comparison, and full-text scope checks of other threshold and two-dimensional ionization results. Their previous reading records are preserved unchanged in scouts05–07. This round does not claim a new complete audit of those papers, preparation experiments, or every general threshold-reflection theorem.

The finite-volume estimate in ROUNDING.md is given directly using elementary exponential weights and Duhamel's identity. It is not presented as a new Lieb–Robinson principle or a sharp quantum propagation velocity. The computational reduction of a finite torus combines exact degenerate momentum weights, while the infinite lattice requires spectral quadrature. Their roles are kept distinct.

## What the background does not establish

A useful mathematical family is not a laboratory specification. The complete five-to-ten-primary-paper audit for the joint preparation, calibrated local minimum, finite coherent area, time dependence and recapture measurement remains incomplete. A fixed local minimum eventually restores gapped return; a finite nonzero-minimum sequence yielding low return does not establish indefinite robustness to fixed hardware errors.

The present evidence supports a more explicit physical window for the same result. It does not establish all trap-shape universality, a full rounding crossover, optimal lattice size, technological advantage, exhaustive priority, or independent proof review. No researcher was contacted, and no established repository was accessed.
